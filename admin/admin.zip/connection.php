<?php
	$conn = mysqli_connect("localhost","root","","kingsmanhomestay");
	mysqli_set_charset($conn, 'UTF8');
 ?>
